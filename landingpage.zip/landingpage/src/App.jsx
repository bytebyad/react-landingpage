import React from 'react'
import { Hero } from './components/HeroSection/Hero'
import { Services } from './components/ServiceSection/Services'
// import './index.css'

function App() {

  return (
    <main className='overflow-x-hidden bg-light text-dark'>
      <Hero />
      <Services />
    </main>
  )
}

export default App
